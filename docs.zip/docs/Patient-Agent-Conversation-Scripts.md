# Patient ↔ Agent conversation scripts

Demo and QA scripts for the **Patient Scheduling Agent** (Onco Global). Aligns with `Data-Model-Objects-And-Fields.md` and backlog flows (`HC_Get_Facilities`, **`HC_DirectoryInvocable`** / **`HC_Find_Specialist`**, **`HC_SymptomRoutingInvocable`** *(planned)*, **`HC_SlotSuggestionInvocable`** *(planned)*, **`HC_BookingActionsInvocable`**, Knowledge, insurance, prerequisites, room rates, rebooking).

**Conventions**

- **Patient** — end user (web or messaging).
- **Agent** — Agentforce reply (shorten in UI as needed).
- Placeholders: `[PatientName]`, `[FacilityName]`, `[DateTime]`, `[ConfirmationCode]` — replace at demo time.
- Clinical advice: agent stays **navigational + scheduling**; medical decisions go to a clinician.

### Verification & channels (MVP)

Identity rules below are the **default for now** (e.g. no SMS OTP). They may change later (OTP, Salesforce Identity, tighter channel policies).

| Channel | How we treat “verification” |
|--------|------------------------------|
| **Web (guest)** | We match the mobile the user gives to the number on the **patient profile** (`PersonMobilePhone` or agreed field). If there is **no** match or **more than one** match, we **do not** self-serve book—hand off or ask them to sign in / call. |
| **Web (logged in)** | The user is **signed in**; we use their **profile / Account** from the session directly for booking and related actions. |
| **WhatsApp** | We use the **number they are messaging from** and match it to the patient profile **when possible**; same uniqueness and safety rules as guest web if mapping is ambiguous. |

---

## 1. Opening & scope

**Patient:** Hi, I need help with an appointment at Onco Global.

**Agent:** Hello — I’m Onco Global’s digital assistant. I can help you find hospitals and specialists, book or change appointments, and answer general questions about visits and preparation. I can’t diagnose conditions or replace your care team. What would you like to do today?

**Patient:** What can you actually do?

**Agent:** I can: list our centers and locations; find a doctor by specialty or department; book, reschedule, or cancel an appointment; check general prep and documents; share non-binding room-rate information where we have it; and help with common scheduling questions. For emergencies, please use emergency services or your nearest ER.

---

## 2. Hospital locations & facilities

**Patient:** Where are your hospitals in India?

**Agent:** I can list Onco Global hospitals from our network. Do you have a preferred city or state, or should I show all major locations?

**Patient:** I’m in Delhi NCR.

**Agent:** Here are facilities we have in the Delhi NCR area: [list from `HealthcareFacility` + `Location` / address]. Would you like directions or to pick one for an appointment?

**Patient:** Which one has medical oncology?

**Agent:** I’ll check which Delhi NCR sites have medical oncology coverage through our provider network. One moment — [results tied to `HealthcarePractitionerFacility` + specialties]. Site A and Site B both list medical oncologists. Would you like to book at one of these?

---

## 3. Nearest site / geo (coarse)

**Patient:** I’m traveling to Mumbai next week. Which hospital is closest to Bandra?

**Agent:** I can suggest facilities in the Mumbai area. For “closest,” I use our registered addresses and locations — [facilities near Mumbai]. If you share a landmark or postal code, I can narrow this further. None of this replaces GPS navigation apps for door-to-door directions.

---

## 4. Specialty & oncology navigation (Knowledge + directory)

**Patient:** What does “surgical oncology” mean at your network?

**Agent:** In general terms, surgical oncology focuses on cancer treatment that may involve surgery, as part of a larger care plan. Exact services vary by hospital and doctor. I can show you surgical oncologists at a location you choose, or link you to our general preparation articles — but I won’t interpret your symptoms or tell you which treatment you need.

**Patient:** Okay — show me surgical oncologists in Bengaluru.

**Agent:** Here are specialists matching surgical oncology in Bengaluru: [top N from `HC_Find_Specialist`]. Would you like to book with one of them, or only see the hospital list first?

---

## 4a. Smart Navigator — symptom phrases (**education-only**)

Routing from common phrases to a **recommended specialty** uses **`Symptom_Specialty_Map__c`** + **`HC_SymptomRoutingInvocable`** *(planned)* — then **`HC_DirectoryInvocable`** with city + specialty. This is **not** triage or diagnosis.

**Patient:** I’ve had a lump in my neck for a few weeks — who should I see?

**Agent:** I’m sorry you’re dealing with that — I can’t examine you or say what it is. In our network, patients often **start with a consultation in medical oncology or ENT** depending on symptoms and local practice — I’ll use general routing guidance only. Which **city** are you looking at?

**Patient:** Jaipur.

**Agent:** Based on general navigation (**not** a diagnosis), medical oncology is a reasonable first scheduling step for many patients with that concern — here are oncologists in Jaipur: [ **`HC_DirectoryInvocable`** after **`HC_SymptomRoutingInvocable`** ]. Would you like to pick a doctor or see hospitals first?

**Patient:** Emergency — chest pain and sweating now.

**Agent:** That can be serious. Please **call emergency services or go to the nearest ER** now. I can’t assess emergencies in chat.

---

## 5. Doctor discovery — city + specialty

**Patient:** I need a medical oncologist in Hyderabad.

**Agent:** Here are medical oncologists practicing at our Hyderabad facilities: [names, facilities, `HealthcareProvider` / `Contact` context]. Who would you prefer, or should I pick the next available slot across these doctors?

**Patient:** Tell me more about the first doctor.

**Agent:** I can share what’s in our directory — name, hospital(s), and specialty focus. For detailed clinical fit, our scheduling team or the doctor’s office can help after you book a consultation.

---

## 6. Department browse (e.g. gynecology, pediatrics)

**Patient:** I don’t know the exact specialty — I need the women’s cancer department. Is that gynecology oncology?

**Agent:** Yes — many patients ask for “gynecology oncology” or GYN oncology. I’ll search our network for providers and departments mapped to that area: [results via `HealthcareProviderSpecialty` / `Specialty` / your department mapping]. Would you like doctors only, or hospitals that offer this service?

**Patient:** Doctors in Chennai.

**Agent:** Here are GYN oncology specialists linked to Chennai sites: [list]. Shall we start booking?

---

## 7. Book appointment — specific doctor

**Patient:** I want to book with Dr. Rao at your Chennai center next Tuesday afternoon.

**Agent:** I’ll check Dr. Rao’s openings at [FacilityName] for next Tuesday afternoon — [options from **`HC_SlotSuggestionInvocable`** *(planned)* → subtract booked **`ServiceAppointment`** rows, or numbered list]. I need your patient record — please confirm the mobile number we have on file, or your patient ID, so I can attach this booking safely.

**Patient:** My mobile is 98xxxxxx01.

**Agent:** Thank you. I found your profile as [PatientName]. Proposed slot: Tuesday, [DateTime], with Dr. Rao at [FacilityName]. Shall I confirm?

**Patient:** Yes, confirm.

**Agent:** Your appointment is confirmed. Reference: [ConfirmationCode]. You’ll receive an SMS summary. A clinical visit record is created in our system for the care team. Anything else — prep instructions or directions?

---

## 8. Book appointment — department only (no named doctor)

**Patient:** I don’t care which doctor — I just need medical oncology in Gurgaon, any morning next week.

**Agent:** I’ll find the next available medical oncology slots across Gurgaon facilities for mornings next week — [ **`HC_SlotSuggestionInvocable`** *(planned)* using **`OperatingHours`**/**`TimeSlot`** − booked visits ]. Option 1: [Facility A], Dr. [X], [DateTime]. Option 2: [Facility B], Dr. [Y], [DateTime]. Which should I book?

**Patient:** Option 1.

**Agent:** To book Option 1 I need to verify you — mobile or patient ID please.

**Patient:** [Provides verification]

**Agent:** Booked — [summary]. Reference: [ConfirmationCode].

---

## 9. Slots / capacity (“how busy are you?”)

**Patient:** Is Tuesday very full at the Mumbai hospital?

**Agent:** I can share high-level availability — for example, how many slots remain versus our daily limit where configured [`Max_Daily_Appointments__c` + same-day `ServiceAppointment` counts], and **proposed times** from clinic hours [`OperatingHours`/`TimeSlot`] minus what’s already booked. Tuesday at [FacilityName] still has openings in several departments; exact counts change in real time. Would you like me to hold a specific time?

---

## 10. Modify appointment (reschedule)

**Patient:** I need to move my Thursday appointment to Friday same time.

**Agent:** I can help reschedule. Please confirm your mobile or patient ID, and if you know the appointment reference or hospital name, that speeds things up.

**Patient:** 98xxxxxx01, it was at Delhi.

**Agent:** I found a Thursday visit at [FacilityName]. Available Friday slots near the same time: [list]. Pick one?

**Patient:** Friday 11:30.

**Agent:** Updated. New time: Friday [DateTime] at [FacilityName]. Reference updated: [ConfirmationCode]. You should get a confirmation message shortly.

---

## 11. Cancel appointment

**Patient:** Cancel my appointment next Monday — I’m traveling.

**Agent:** I’m sorry you can’t make it. I’ll locate Monday’s booking — please verify mobile or patient ID.

**Patient:** [Verifies]

**Agent:** I see Monday [DateTime] with [Doctor] at [Facility]. Should I cancel this appointment?

**Patient:** Yes, cancel it.

**Agent:** It’s canceled. If you’d like to rebook when you return, I can help find a new slot. Would you like that?

---

## 12. Insurance on file (read-only list)

**Patient:** Do you have my insurance details?

**Agent:** I can show what we have on file for your profile — payer name, plan label, and high-level eligibility status from our records [`Patient_Insurance__c`]. I don’t guarantee payment; final eligibility is determined at registration and with your payer.

**Patient:** What plans show up?

**Agent:** For [PatientName], we show: (1) [Payer] — [Plan] — status [Active/Pending/etc.]; (2) … If something looks wrong, you can upload an updated card or speak with registration at your visit.

---

## 13. Prerequisites before counselling (checklist)

**Patient:** I have a counselling session booked — what documents do I need?

**Agent:** For your upcoming counselling appointment, our checklist shows: [items from `Counselling_Prerequisite__c` — e.g. ID, insurance card, consent, lab report if required]. Items marked required must be completed before session. Which item do you want to tackle first?

**Patient:** I uploaded my insurance card yesterday.

**Agent:** Thank you — I’ll reflect that against your appointment checklist when our system processes the file. If anything is still missing, I’ll list only the open items. You can also upload missing documents through your patient link or at the front desk.

---

## 14. Room rates (informational, non-binding)

**Patient:** How much is a private room per day at your Jaipur hospital?

**Agent:** For [FacilityName], our non-binding reference rates show: Private room — approximately [Daily_Rate__c] per day for the current rate window [`Facility_Room_Rate__c`]. Rates depend on acuity, insurance, and taxes — this is **not** a quote or guarantee. For a financial estimate, billing can help after admission planning.

**Patient:** What about ICU?

**Agent:** For ICU at the same site, the reference band is [rate]. Again, this is illustrative only for planning conversations.

---

## 15. Returning patient / rebook (Booking_Session context)

**Patient:** I was there last month — book something similar in Kolkata.

**Agent:** Welcome back. I can use your last visit preferences where we have them [`Booking_Session__c` / last `ServiceAppointment` / `Preferred_Facility__c`]. Your last booking was [summary]. Should I search the same specialty in Kolkata for the next two weeks?

**Patient:** Yes, same specialty.

**Agent:** Here are next available options in Kolkata: [slots]. Which works?

---

## 16. Knowledge / FAQ (no database write)

**Patient:** What should I bring on the first visit?

**Agent:** Generally: a government-issued ID, insurance information, a list of current medications, and any prior reports you have. Your exact checklist can vary by appointment type — I can pull our patient FAQ article: [short summary from `Knowledge__kav`]. Want me to add prep to your calendar description in the confirmation SMS?

---

## 17. Check-in / arrival (informational)

**Patient:** When should I arrive?

**Agent:** Many sites ask you to arrive 15–20 minutes before your scheduled time for registration. Your confirmation shows [DateTime] — plan to be a little early. For check-in status updates, the front desk or kiosk will confirm when you’re checked in [`CheckedInTime` where used].

---

## 18. No results / graceful empty state

**Patient:** Do you have any surgical oncologists in Shillong?

**Agent:** I don’t see a surgical oncologist at our Onco Global locations in Shillong in the directory I queried. I can: show the nearest cities where we do have coverage, or help you leave a message for our contact center. Which do you prefer?

---

## 19. Verification failure / safety

**Patient:** Book an appointment for mobile 99xxxxxx99.

**Agent:** I couldn’t match that number to a patient profile in our system. Please double-check the number, try another verified identifier we have on file, or say “contact center” and I’ll share how to reach the seven-member team during business hours.

---

## 20. Agent action logging (judge-visible behavior)

**Patient:** Find a radiation oncologist in Mumbai.

**Agent:** [After tool run] Here are radiation oncologists in Mumbai: [list].

*(Internal / demo narration: a row is written to `Agent_Action_Log__c` with `Action_Name__c` e.g. HC_Find_Specialist, `Status__c` Success, `Correlation_Id__c` tied to this session.)*

---

## 21. Failure after tool / partial error

**Patient:** Book me any slot tomorrow at Gurgaon medical oncology.

**Agent:** I wasn’t able to complete the booking — [safe reason: e.g. no open slots / validation]. Nothing was confirmed. I can try another day or facility, or escalate you to scheduling. What would you like?

*(Demo: `Agent_Action_Log__c` with `Status__c` Failed, `Error_Message__c` sanitized.)*

---

## 22. WhatsApp-style (short turns) — optional channel

**Patient:** Slots Gurgaon oncology tomorrow?

**Agent:** Few slots left tomorrow AM at [Facility A]; PM tighter. Want a specific time?

**Patient:** 10am any doc.

**Agent:** Need quick verify — reply with last 4 digits of registered mobile.

**Patient:** xx01

**Agent:** Booked 10:00 [Facility A], Dr. [X]. Ref [ConfirmationCode].

---

## 23. Escalation & boundaries

**Patient:** My tumor marker doubled — what should I do?

**Agent:** I’m not able to interpret lab results or give medical advice. Please message your care team through your portal or call your oncologist’s office directly. If you have sudden severe symptoms, use emergency services.

**Patient:** Connect me to a human for scheduling only.

**Agent:** For scheduling with a live agent, you can reach our contact center at [published number] during [hours]. I can also stay with you to find a self-service slot if you prefer.

---

## 24. Closing

**Patient:** That’s all, thanks.

**Agent:** You’re welcome. Your confirmations are on the way. Good luck with your visit — if anything changes, you can return here to reschedule or cancel. Take care.

---

## Script → feature matrix (quick QA)

| # | Scenario | Primary objects / assets |
|---|----------|---------------------------|
| 1 | Opening & scope | Instructions only |
| 2–3 | Locations & geo | `HealthcareFacility`, `Location`, optional `Account` (facility org) |
| 4 | Specialty education | `Knowledge__kav`, directory |
| 5–6 | Doctor / department discovery | `HealthcareProvider`, `Contact`, `HealthcarePractitionerFacility`, `HealthcareProviderSpecialty`, `Specialty` |
| 7–9 | Book (named / dept / capacity) | `ServiceAppointment`, `ClinicalEncounter`, `ClinicalEncounterProvider`; `Max_Daily_Appointments__c`; slot suggestions via **`OperatingHours`**/**`TimeSlot`** (Approach A — see data dictionary) |
| 10–11 | Modify / cancel | Same as booking lifecycle |
| 12 | Insurance | `Patient_Insurance__c`, patient `Account` |
| 13 | Prerequisites | `Counselling_Prerequisite__c`, `ServiceAppointment`, files |
| 14 | Room rates | `Facility_Room_Rate__c`, `HealthcareFacility` |
| 15 | Rebook | `Booking_Session__c`, lookups to SA / encounter / facility |
| 16 | FAQ | `Knowledge__kav` |
| 17 | Check-in copy | `ServiceAppointment` (times) |
| 18–19 | Empty / verify fail | Flow fault paths |
| 20–21 | Logging | `Agent_Action_Log__c` |
| 22 | WhatsApp tone | Same flows, shorter copy |
| 23 | Escalation | Policy / handoff |
| 24 | Close | — |

---

*Add new scripts when you introduce Care programs (`CareProgram`, `CareProgramEnrollee`) or Messaging (`MessagingSession`).*
